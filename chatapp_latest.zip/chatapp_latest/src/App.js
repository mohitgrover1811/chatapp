import './App.css';
import LoginNew from './components/LoginNew/LoginNew';
import ChatNew from './components/chatNew/ChatNew';
import { Routes, Route } from 'react-router-dom';
import Register from './components/Register/Register';
import SetAvatar from './components/SetAvatar/SetAvatar';

function App() {
	return (
		<div className='App'>
			{/* <Navbar /> */}
			<Routes>
				<Route path='/signup' element={<Register />} />
				<Route path='/' element={<LoginNew />} />
				<Route path='/chat' element={<ChatNew />} />
				<Route path='/setAvatar' element={<SetAvatar />} />
			</Routes>
		</div>
	);
}

export default App;
