import { setItem, getItem, clear } from '../Helpers/LocalStorage';

export const sendMessage = (data) => {
	return {
		type: 'SENDMESSAGE',
		payload: data,
	};
};
export const deleteMessage = () => {
	return {
		type: 'DELETEMESSAGE',
	};
};
export const registeruser = (user) => {
	return {
		type: 'CREATE_USER',
		payload: user,
	};
};
export const updateUser = (user) => {
	return {
		type: 'UPDATE_USER',
		payload: user,
	};
};
export const currentUser = (id) => {
	return {
		type: 'CURRENT_USER',
		payload: id,
	};
};

export const createUser = (user) => (dispatch) => {
	const getusers = getItem('users') || [];
	setItem('users', [...getusers, user]);
	dispatch(registeruser(user));
};

export const saveChatBot = (data, users, id) => (dispatch) => {
	const newMessage = users.map((user) =>
		user.id === id
			? {
					...user,
					messages: [...user.messages, { ...data, author: 'bot' }],
			  }
			: user,
	);
	console.log(
		newMessage,
		'data ========',
		users[0].id === id,
		'gchg',
	);
	setItem('users', newMessage);
	dispatch(updateUser(newMessage));
	return;
};

export const saveChat = (data, users, id) => (dispatch) => {
	const newMessage = users.map((user) =>
		user.id === id
			? { ...user, messages: [...user.messages, { ...data }] }
			: user,
	);
	console.log(newMessage, 'data ========', users[0].id === id);
	setItem('users', newMessage);
	dispatch(updateUser(newMessage));
	const start = setTimeout(() => {
		dispatch(saveChatBot(data, newMessage, id));
	}, 3000);

	return () => clearTimeout(start);
	return;
};

export const deleteChat = (data) => (dispatch) => {
	clear('chatmsg', []);
	dispatch(deleteMessage(data));
};
