import React, { useState } from "react";
import styled from "styled-components";
import { useNavigate, Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { setItem } from "../../Helpers/LocalStorage";
import { KEYS } from "../../utils/constants";

export default function LoginNew() {
    const navigate = useNavigate();
    const [user, setUser] = useState({ email: "", password: "" });

    const userData = useSelector((state) => state.reducers.userData);

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const onSuccess = (user) => {
        navigate("/chat");
        setItem(KEYS.CURRENTUSER, user.id)
    }

    const handleClick = () => {
        if (user.email === "" && user.password === "") {
            alert("please enter email");
            return;
        }
        const alreadyUser = userData?.find((item) => item?.email === user?.email);
        !alreadyUser && alert("user is not registered");
        !alreadyUser
            ? navigate("/signup")
            : alreadyUser.password === user.password
                ? onSuccess(alreadyUser)
                : alert("password is wrong");
    };

    const Register = () => {
        navigate('./')
    }

    return (
        <>
            <FormContainer>
                <form action="" onSubmit={(event) => handleClick(event)}>
                    <div className="brand">
                        <h1>snappy</h1>
                    </div>
                    <input
                        type="text"
                        placeholder="Username"
                        name="username"
                        onChange={(e) => handleChange(e)}
                        min="3"
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        name="password"
                        onChange={(e) => handleChange(e)}
                    />
                    <button type="submit">Log In</button>
                    <span>
                        Don't have an account ? <Link to="/signup">Create One.</Link>
                    </span>
                </form>
            </FormContainer>
        </>
    );
}

const FormContainer = styled.div`
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 1rem;
  align-items: center;
  background-color: #131324;
  .brand {
    display: flex;
    align-items: center;
    gap: 1rem;
    justify-content: center;
    img {
      height: 5rem;
    }
    h1 {
      color: white;
      text-transform: uppercase;
    }
  }

  form {
    display: flex;
    flex-direction: column;
    gap: 2rem;
    background-color: #00000076;
    border-radius: 2rem;
    padding: 5rem;
  }
  input {
    background-color: transparent;
    padding: 1rem;
    border: 0.1rem solid #4e0eff;
    border-radius: 0.4rem;
    color: white;
    width: 100%;
    font-size: 1rem;
    &:focus {
      border: 0.1rem solid #997af0;
      outline: none;
    }
  }
  button {
    background-color: #4e0eff;
    color: white;
    padding: 1rem 2rem;
    border: none;
    font-weight: bold;
    cursor: pointer;
    border-radius: 0.4rem;
    font-size: 1rem;
    text-transform: uppercase;
    &:hover {
      background-color: #4e0eff;
    }
  }
  span {
    color: white;
    text-transform: uppercase;
    a {
      color: #4e0eff;
      text-decoration: none;
      font-weight: bold;
    }
  }
`;
