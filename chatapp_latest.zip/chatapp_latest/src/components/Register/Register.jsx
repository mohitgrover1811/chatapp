import React, { useState } from "react";
import styled from "styled-components";
import { useNavigate, Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { createUser } from "../../actions/action";
import loader from "../../assets/loader.gif";
import axios from "axios";
import { Buffer } from "buffer";

export default function Register() {
    const [user, setUser] = useState({});
    const [selectAvatar, setSelectAvatar] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const navigate = useNavigate();
    const api = `https://api.multiavatar.com/4645646`;
    const [avatars, setAvatars] = useState([]);
    const [selectedAvatar, setSelectedAvatar] = useState(undefined);

    const dispatch = useDispatch();

    const userData = useSelector((state) => state.reducers.userData);

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value })
    }

    const setProfilePicture = async () => {
        if (selectedAvatar === undefined) {
        } else {
            user.isAvatarImageSet = true;
            user.avatarImage = avatars[selectedAvatar];
            const payload = { ...user, id: Date.now().toLocaleString(), messages: [] }
            console.log(payload);
            const alreadyUser = userData?.find((item) => item?.email === user?.email)
            alreadyUser && alert('user already exists')
            alreadyUser ? navigate('/') : dispatch(createUser(payload))
            setUser({ username: '', email: '', password: '' })
            console.log(userData, 'userdatatat');
            navigate('/chat');
        }
    };


    const myfunction = async () => {
        const data = [];
        for (let i = 0; i < 4; i++) {
            const image = await axios.get(
                `${api}/${Math.round(Math.random() * 1000)}`
            );
            console.log("image found");
            const buffer = new Buffer(image.data);
            console.log(image.data);
            data.push(buffer.toString("base64"));
        }
        console.log(data);
        setAvatars(data);
        setIsLoading(false);
    }

    const selectProfile = () => {

    }

    const handleClick = () => {
        setIsLoading(true);
        setSelectAvatar(true);
        myfunction();
    }
    return (
        <>
            {
                selectAvatar ?
                    isLoading ? (
                        <Container>
                            <img src={loader} alt="loader" className="loader" />
                        </Container>
                    ) : (
                            <Container>
                                <div className="title-container">
                                    <h1>Pick an Avatar as your profile picture</h1>
                                </div>
                                <div className="avatars">
                                    {avatars.map((avatar, index) => {
                                        return (
                                            <div
                                                className={`avatar ${selectedAvatar === index ? "selected" : ""
                                                    }`}
                                            >
                                                <img
                                                    src={`data:image/svg+xml;base64,${avatar}`}
                                                    alt="avatar"
                                                    key={avatar}
                                                    onClick={() => setSelectedAvatar(index)}
                                                />
                                            </div>
                                        );
                                    })}
                                </div>
                                <button onClick={setProfilePicture} className="submit-btn">
                                    Set as Profile Picture
                  </button>
                            </Container>
                        ) : (
                        <FormContainer>
                            <form action="" onSubmit={(event) => handleClick(event)}>
                                <div className="brand">
                                    <h1>snappy</h1>
                                </div >
                                <input
                                    type="text"
                                    placeholder="Username"
                                    name="username"
                                    onChange={(e) => handleChange(e)}
                                />
                                <input
                                    type="email"
                                    placeholder="Email"
                                    name="email"
                                    onChange={(e) => handleChange(e)}
                                />
                                <input
                                    type="password"
                                    placeholder="Password"
                                    name="password"
                                    onChange={(e) => handleChange(e)}
                                />
                                <button type="submit">Create User</button>
                                <span>
                                    Already have an account ? <Link to="/">Login.</Link>
                                </span>
                            </form >
                        </FormContainer >
                    )
            }
        </>
    );
}

const FormContainer = styled.div`
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 1rem;
  align-items: center;
  background-color: #131324;
  .brand {
    display: flex;
    align-items: center;
    gap: 1rem;
    justify-content: center;
    img {
      height: 5rem;
    }
    h1 {
      color: white;
      text-transform: uppercase;
    }
  }

  form {
    display: flex;
    flex-direction: column;
    gap: 2rem;
    background-color: #00000076;
    border-radius: 2rem;
    padding: 3rem 5rem;
  }
  input {
    background-color: transparent;
    padding: 1rem;
    border: 0.1rem solid #4e0eff;
    border-radius: 0.4rem;
    color: white;
    width: 100%;
    font-size: 1rem;
    &:focus {
      border: 0.1rem solid #997af0;
      outline: none;
    }
  }
  button {
    background-color: #4e0eff;
    color: white;
    padding: 1rem 2rem;
    border: none;
    font-weight: bold;
    cursor: pointer;
    border-radius: 0.4rem;
    font-size: 1rem;
    text-transform: uppercase;
    &:hover {
      background-color: #4e0eff;
    }
  }
  span {
    color: white;
    text-transform: uppercase;
    a {
      color: #4e0eff;
      text-decoration: none;
      font-weight: bold;
    }
  }
`;

const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 3rem;
  background-color: #131324;
  height: 100vh;
  width: 100vw;

  .loader {
    max-inline-size: 100%;
  }

  .title-container {
    h1 {
      color: white;
    }
  }
  .avatars {
    display: flex;
    gap: 2rem;

    .avatar {
      border: 0.4rem solid transparent;
      padding: 0.4rem;
      border-radius: 5rem;
      display: flex;
      justify-content: center;
      align-items: center;
      transition: 0.5s ease-in-out;
      img {
        height: 6rem;
        transition: 0.5s ease-in-out;
      }
    }
    .selected {
      border: 0.4rem solid #4e0eff;
    }
  }
  .submit-btn {
    background-color: #4e0eff;
    color: white;
    padding: 1rem 2rem;
    border: none;
    font-weight: bold;
    cursor: pointer;
    border-radius: 0.4rem;
    font-size: 1rem;
    text-transform: uppercase;
    &:hover {
      background-color: #4e0eff;
    }
  }
`;
