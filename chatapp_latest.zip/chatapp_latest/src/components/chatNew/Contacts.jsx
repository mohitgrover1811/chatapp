import React, { useState, useEffect } from "react";
import styled from "styled-components";

export default function Contacts({ contacts, changeChat }) {
  const [currentUserName, setCurrentUserName] = useState(undefined);
  const [currentUserImage, setCurrentUserImage] = useState(undefined);
  const [currentSelected, setCurrentSelected] = useState(undefined);
  useEffect(() => {
    const data = {
      userName: 'admin200',
      email: 'admin200@gmail.com ',
      password: 'admin200',
      isAvatarImageSet: true,
      avatarImage: 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMzEgMjMxIj48cGF0aCBkPSJNMzMuODMsMzMuODNhMTE1LjUsMTE1LjUsMCwxLDEsMCwxNjMuMzQsMTE1LjQ5LDExNS40OSwwLDAsMSwwLTE2My4zNFoiIHN0eWxlPSJmaWxsOiMwZGY7Ii8+PHBhdGggZD0ibTExNS41IDUxLjc1YTYzLjc1IDYzLjc1IDAgMCAwLTEwLjUgMTI2LjYzdjE0LjA5YTExNS41IDExNS41IDAgMCAwLTUzLjcyOSAxOS4wMjcgMTE1LjUgMTE1LjUgMCAwIDAgMTI4LjQ2IDAgMTE1LjUgMTE1LjUgMCAwIDAtNTMuNzI5LTE5LjAyOXYtMTQuMDg0YTYzLjc1IDYzLjc1IDAgMCAwIDUzLjI1LTYyLjg4MSA2My43NSA2My43NSAwIDAgMC02My42NS02My43NSA2My43NSA2My43NSAwIDAgMC0wLjA5OTYxIDB6IiBzdHlsZT0iZmlsbDojYzM2YzAwOyIvPjxwYXRoIGQ9Ik02MS4xMSwyMDUuNTlsMy40OSwzLjY5LTYuMjYsNi42QTExNS40NSwxMTUuNDUsMCwwLDAsNzIsMjIyLjUxdi0yMmExMTUuMTksMTE1LjE5LDAsMCwwLTEwLjg1LDUuMVoiIHN0eWxlPSJmaWxsOiNlZmVkZWU7Ii8+PHBhdGggZD0iTTkzLjI0LDIyOC44NVYxOTlsLTQtNEExMTQuNDMsMTE0LjQzLDAsMCwwLDcyLDIwMC40OXYyMmExMTQuNDMsMTE0LjQzLDAsMCwwLDIxLjI4LDYuMzRaIiBzdHlsZT0iZmlsbDojZWMwMDMzOyIvPjxwYXRoIGQ9Im0xNTkgMjIyLjUxdi0yMmExMTQuNjMgMTE0LjYzIDAgMCAwLTE3LjI1LTUuNTFsLTQgNHYyOS44NmExMTQuMTYgMTE0LjE2IDAgMCAwIDIxLjI1LTYuMzV6IiBzdHlsZT0iZmlsbDojZWMwMDMzOyIvPjxwYXRoIGQ9Im0xNjkuODkgMjA1LjU5LTMuNDkgMy42OSA2LjI2IDYuNmExMTUuNDUgMTE1LjQ1IDAgMCAxLTEzLjY2IDYuNjN2LTIyYTExNS4xOSAxMTUuMTkgMCAwIDEgMTAuODUgNS4xeiIgc3R5bGU9ImZpbGw6I2VmZWRlZTsiLz48cGF0aCBkPSJNMTE1LjUsMjE5LjYyQTI4LjUsMjguNSwwLDAsMSw4Ny4yNSwxOTVjMi45My0uNzQsNS45Mi0xLjM2LDguOTQtMS44N2ExOS40MSwxOS40MSwwLDAsMCwzOC42MiwwYzMsLjUxLDYsMS4xMyw4Ljk0LDEuODdhMjguNDksMjguNDksMCwwLDEtMjguMjUsMjQuNjNaIiBzdHlsZT0iZmlsbDojZjJmZjA1OyIvPjxwYXRoIGQ9Im00MS42NjggODcuMDczYy05LjIzMTktMC4wMjMxLTExLjYzIDYuNTEwNCAyLjI2NzYgMTcuNjYtMTQuMDE1IDEuMTIzMS00LjM2NjIgMTYuNDU3IDQuODc1IDI0LjY2IDQuMDY4NiAzLjAxOTkgNi40NjQ3IDUuNDY1NyA1LjUwNzggMS4xMzQ4LTEuMjA3OS00LjkxNzgtMS44MTg0LTkuOTYzNC0xLjgxODQtMTUuMDI3IDMuMjZlLTQgLTcuNTY5MiAxLjI1NDctMTUuMDE2IDMuNzg4My0yMi4xODMgMC41NzA0OC0xLjc4NzYgMS4wNjg5LTIuMDMwNi0wLjM3NzIxLTIuNjgzOS01LjU0MDUtMi40NDc4LTEwLjM3NS0zLjU1MTEtMTQuMjQzLTMuNTYwOHoiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+PHBhdGggZD0ibTE4NS40OCA4OS41MTNjLTIuNDQxOC0wLjExMTg5LTUuNDYxOCAwLjgxMTg3LTkuNTE0OCAzLjIxMjEtMS4zMTQgMC44MTcyOS0wLjcwMDc1IDEuOTk1LTAuMzIzMDEgMy4yNjUzIDMuMTk0IDEwLjk4MiAzLjgyMTUgMjIuNDYyIDEuMjUzOCAzMy42MjgtMC4zMTYxMyAxLjY4OC0wLjQ3NjQ5IDMuNTY5IDIuNjk1MyAxLjM1MTYgNy43MDE2LTUuMzcxIDE5LjE3LTE4LjczNCAxNi45MTgtMjYuMTA1LTEuNDI1MS0zLjkxNzctMTEuNC0wLjM1NTQ2LTExLjQtMC4zNTU0NnM0Ljk4Ny00LjI3NTUgNS4zNDM3LTkuNjE5MWMwLjIwMDQ4LTMuMDA1Ny0xLjUyMzctNS4yMTg5LTQuOTcyNi01LjM3N3oiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+PHBhdGggZD0ibTkxLjY4OSAzNi4xMDhjLTMuNzI5OC03LjM4NjQtOS41ODU5LTEwLjUwNC0xNy41NzgtNi43ODkxLTkuNTE5NCA0LjU5MDctMTUuNjI5IDE4LjQ0NC0xMy40MTYgMjkuMjMyIDAgMC04LjU1MTEtNC45ODc4LTE4LjE3LTMuNTYyNS0xOS42MjMgOC4wOTQtMS40MTAyIDI5Ljg2OSAxMC44MTcgMzcuMzQyIDIuMDc1IDEuMjk3IDIuNTc5MiAxLjc0MzIgMy40MjkxLTAuMzc2ODUgMi42NzQ2LTYuNTM3NCA2LjE4ODYtMTIuNzIyIDExLjI5Ny0xNy43MDkgNC4xMDM5IDguNzQyNyAxNC42MjkgNC4xODA5IDIwLjAwNi0wLjE0MDYyIDQuNDg3MyA5LjY4MzggMTAuMzc3IDYuMzUzNSAxNS4zNzcgMy40Nzg1IDQuMDc2NCA3Ljg4MjkgMTAuNzU2IDcuMjUgMTcuNjMxIDAuMDYyNSA0Ljg3NSA0LjU2MjUgMTQuNzEzIDQuMTg2NyAxNS41NTUtMy40MjYgOC40NzUzIDIuNjI0NCAxNC4wMTIgMTAuNDM3IDIyLjk2Mi0xLjQ3NjQgOC44NTUyIDYuODIyMSAxNC40MDcgMTYuODUzIDE3LjEyMiAyNy41MSAwLjM0IDEuNTU0IDEuMTc1IDAuODU1NjUgMi4yMjEyIDAuNDQzMTUgMTAuMjU1LTQuMjg2IDIyLjg0Mi0xNS43NDkgMTUuNzA1LTIzLjk3NS0zLjU2MjMtMy41NjIzLTEzLjUzOS0yLjEzODctMTMuNTM5LTIuMTM4N3M2Ljc3LTcuMTIzMyA5LjI2MzctMTguMTY4YzIuNDkzNi0xMS4wNDMtMjMuNTE0LTQuOTg4My0yMy41MTQtNC45ODgzczcuNDgxOC01LjY5OTMgMTIuMTEzLTEzLjUzN2M0LjYzMTQtNy44Mzc4LTIuNDk0My0xMS43NTYtMTEuMDQ1LTExLjA0My04LjU0OTYgMC43MTIwNC0xNy4xIDcuNDgwNS0xNy4xIDcuNDgwNXMzLjM5NDYtNy44MDU1LTMuNTYyNS0xMi44MjZjLTkuNTkzNS02LjkyMzQtMjMuODY5IDYuNDEyMS0yMy44NjkgNi40MTIxLTQuMjU2Mi0yNi44MzUtMjQuODcyLTYuMzg2LTMxLjcwNyA4LjE5NTN6IiBzdHlsZT0iZmlsbDojNjMzYjFkOyIvPjxwYXRoIGQ9Im0xNzAuMjUgMTAwYzEuNjkgOS42Mi00Ljc5IDI5LjIzLTIyLjQgMjkuMjMtNi44MSAwLTE1LTMuNjYtMjAuMjMtMTAtNC4zNC01LjMzLTcuNTYtMTIuODctNi4yLTE5LjQ1IDEuNjMtNy44OSA3LjA3LTExLjQ1IDE0LjY3LTEyLjkyYTY4LjE2IDY4LjE2IDAgMCAxIDEyLjUyLTFjMTAuNzcgMCAxOS43OCAzLjYxIDIxLjY0IDE0LjIyeiIgc3R5bGU9ImZpbGw6IzAwYjViNDtzdHJva2Utd2lkdGg6My45OXB4O3N0cm9rZTojMDAwOyIvPjxwYXRoIGQ9Im02MC43NSAxMDBjLTEuNjkgOS42MiA0Ljc5IDI5LjIzIDIyLjQgMjkuMjMgNi44MSAwIDE1LTMuNjYgMjAuMjMtMTAgNC4zNC01LjMzIDcuNTYtMTIuODcgNi4yLTE5LjQ1LTEuNjMtNy44OS03LjA3LTExLjQ1LTE0LjY3LTEyLjkyYTY4LjE2IDY4LjE2IDAgMCAwLTEyLjUyLTFjLTEwLjc3IDAtMTkuNzggMy42MS0yMS42NCAxNC4yMnoiIHN0eWxlPSJmaWxsOiMwMGI1YjQ7c3Ryb2tlLXdpZHRoOjMuOTlweDtzdHJva2U6IzAwMDsiLz48bGluZSB4MT0iMTAwLjIiIHgyPSIxMzAuOCIgeTE9Ijg3LjkyIiB5Mj0iODcuOTIiIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlLWxpbmVjYXA6cm91bmQ7c3Ryb2tlLWxpbmVqb2luOnJvdW5kO3N0cm9rZS13aWR0aDozLjk5cHg7c3Ryb2tlOiMwMDA7Ii8+PHBhdGggZD0ibTEwOS44NyAxMDEuNzNjMC0yLjU5IDIuNTItNC42OSA1LjYzLTQuNjlzNS42MyAyLjEgNS42MyA0LjY5IiBzdHlsZT0iZmlsbDpub25lO3N0cm9rZS13aWR0aDozLjk5cHg7c3Ryb2tlOiMwMDA7Ii8+PHBhdGggZD0ibTExNS42OCAxNjAuNjRjNy4wOCAwIDEzLjExLTQuOTMgMTUuNDYtMTEuODRhMi4xNCAyLjE0IDAgMCAwLTEuNTEtMi42MTAxIDIuMyAyLjMgMCAwIDAtMC43Mzk5NS0wLjA1OTNoLTI2LjQyYTIuMTIgMi4xMiAwIDAgMC0yLjMxIDEuOTA5OSAxLjg1IDEuODUgMCAwIDAgMC4wNTkzIDAuNzM5OTVjMi4zNDAxIDYuOTMwMSA4LjM4MDIgMTEuODYgMTUuNDYgMTEuODZ6IiBzdHlsZT0iZmlsbDojMWExYTFhOyIvPjwvc3ZnPg=='
    };
    setCurrentUserName(data.userName);
    setCurrentUserImage(data.avatarImage);
  }, []);

  const changeCurrentChat = (index, contact) => {
    setCurrentSelected(index);
    changeChat(contact);
  };
  return (
    <>
      {currentUserImage && currentUserImage && (
        <Container>
          <div className="brand">

            <h3>snappy</h3>
          </div>
          <div className="contacts">
            {contacts.map((contact, index) => {
              return (
                <div
                  key={contact._id}
                  className={`contact ${index === currentSelected ? "selected" : ""
                    }`}
                  onClick={() => changeCurrentChat(index, contact)}
                >
                  <div className="avatar">
                    <img
                      src={`data:image/svg+xml;base64,${contact.avatarImage}`}
                      alt=""
                    />
                  </div>
                  <div className="username">
                    <h3>{contact.userName}</h3>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="current-user">
            <div className="avatar">
              <img
                src={`data:image/svg+xml;base64,${currentUserImage}`}
                alt="avatar"
              />
            </div>
            <div className="username">
              <h2>{currentUserName}</h2>
            </div>
          </div>
        </Container>
      )}
    </>
  );
}
const Container = styled.div`
  display: grid;
  grid-template-rows: 10% 75% 15%;
  overflow: hidden;
  background-color: #080420;
  .brand {
    display: flex;
    align-items: center;
    gap: 1rem;
    justify-content: center;
    img {
      height: 2rem;
    }
    h3 {
      color: white;
      text-transform: uppercase;
    }
  }
  .contacts {
    display: flex;
    flex-direction: column;
    align-items: center;
    overflow: auto;
    gap: 0.8rem;
    &::-webkit-scrollbar {
      width: 0.2rem;
      &-thumb {
        background-color: #ffffff39;
        width: 0.1rem;
        border-radius: 1rem;
      }
    }
    .contact {
      background-color: #ffffff34;
      min-height: 5rem;
      cursor: pointer;
      width: 90%;
      border-radius: 0.2rem;
      padding: 0.4rem;
      display: flex;
      gap: 1rem;
      align-items: center;
      transition: 0.5s ease-in-out;
      .avatar {
        img {
          height: 3rem;
        }
      }
      .username {
        h3 {
          color: white;
        }
      }
    }
    .selected {
      background-color: #9a86f3;
    }
  }

  .current-user {
    background-color: #0d0d30;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 2rem;
    .avatar {
      img {
        height: 4rem;
        max-inline-size: 100%;
      }
    }
    .username {
      h2 {
        color: white;
      }
    }
    @media screen and (min-width: 720px) and (max-width: 1080px) {
      gap: 0.5rem;
      .username {
        h2 {
          font-size: 1rem;
        }
      }
    }
  }
`;
