import { getItem } from "../Helpers/LocalStorage";
import { KEYS } from "../utils/constants";


const currentUser = getItem(KEYS.CURRENTUSER) || ''
const users = getItem(KEYS.USERS) || []
const messages = getItem(KEYS.MESSAGES) || []
const fetchedMessages = messages.filter((chats) => chats.userid === currentUser)

const initialData = {
  userData: users,
  Currentuser: currentUser,
  fetchedConvo: fetchedMessages,
  currentBot: 1
  // currentUser: getItem("users")[0].id,
};

const reducers = (state = initialData, action) => {
  switch (action.type) {
    // case "SENDMESSAGE":
    //   return {
    //     ...state,
    //     list: [...state.list, action.payload],
    //   };

    // case "DELETEMESSAGE":
    //   return {
    //     ...state,
    //     list: [],
    //   };

    case "CREATE_USER":
      return {
        ...state,
        userData: [...state.userData, action.payload],
      };

    case "CURRENT_USER":
      return {
        ...state,
        currentUser: action.payload,
      };


    default:
      return state;
  }
};
export default reducers;
