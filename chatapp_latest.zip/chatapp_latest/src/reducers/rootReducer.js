import reducers from "./reducer";
import { combineReducers } from "redux";

const rootReducer = combineReducers({
    reducers
})

export default rootReducer