export const contact = [
    {
        id: '1',
        name: 'John',
        avatar: '',
    },
    {
        id: '2',
        name: 'Peter',
        avatar: '',
    },
    {
        id: '3',
        name: 'Sam',
        avatar: '',
    },
    {
        id: '4',
        name: 'hemant',
        avatar: '',
    },
    {
        id: '5',
        name: 'John',
        avatar: '',
    }
]

export const KEYS = { MESSAGES: 'messages', USERS: 'users', CURRENTUSER: 'user' }